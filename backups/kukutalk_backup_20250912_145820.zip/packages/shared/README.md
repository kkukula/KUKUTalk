packages/shared - placeholder for future shared code
