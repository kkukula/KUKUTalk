require('dotenv').config()
const express = require('express')
const cors = require('cors')
const http = require('http')
const helmet = require('helmet')
const rateLimit = require('express-rate-limit')
const compression = require('compression')
const hpp = require('hpp')
const jwt = require('jsonwebtoken')
const pkg = { name:'kukutalk-backend', version:'0.6.0' }

const { readJson } = require('./lib/store')
const { evaluate, recordViolation, getState } = require('./lib/moderation')
const { createLogger } = require('./lib/logger')
const metrics = require('./lib/metrics')

const { requireAuth, requireRole } = require('./middleware/authz')
const { registerParent, login, me } = require('./routes/auth')
const { createChild, listChildren, addWhitelist } = require('./routes/profiles')
const { getWL, setWL, modStats } = require('./routes/moderation')

const app = express()
const PORT = Number(process.env.PORT || 3001)
const ORIGIN = process.env.CORS_ORIGIN || 'http://localhost:5173'
const ALLOWLIST = (process.env.CORS_ALLOWLIST || ORIGIN).split(',').map(s => s.trim()).filter(Boolean)
const BODY_LIMIT = process.env.BODY_LIMIT || '64kb'
const RATE_WINDOW = Number(process.env.RATE_LIMIT_WINDOW_MS || 60000)
const RATE_MAX = Number(process.env.RATE_LIMIT_MAX || 60)
const MSG_MAX_LEN = Number(process.env.MSG_MAX_LEN || 500)
const MSG_MIN_INTERVAL = Number(process.env.MSG_MIN_INTERVAL_MS || 750)
const ENABLE_CONTROLS = String(process.env.PARENTAL_CONTROLS_ENABLED||'true').toLowerCase() === 'true'
const ENABLE_MOD = String(process.env.MODERATION_ENABLED||'true').toLowerCase() === 'true'
const METRICS_ENABLED = String(process.env.METRICS_ENABLED||'true').toLowerCase() === 'true'
const METRICS_PATH = process.env.METRICS_PATH || '/metrics'
const METRICS_TOKEN = String(process.env.METRICS_TOKEN||'')
const MOD_CFG = {
  maxLinksPerMsg: Number(process.env.MOD_MAX_LINKS_PER_MSG || 0),
  violationsBeforeMute: Number(process.env.MOD_VIOLATIONS_BEFORE_MUTE || 3),
  muteMs: Number(process.env.MOD_MUTE_MS || 600000)
}
const cspConnect = (process.env.CSP_CONNECT || 'http://localhost:5173 ws://localhost:3001').split(/\s+/)

function corsOrigin(origin, cb) {
  if (!origin) return cb(null, true)
  if (ALLOWLIST.indexOf(origin) !== -1) return cb(null, true)
  return cb(new Error('CORS not allowed'), false)
}

app.set('x-powered-by', false)
app.use(hpp())
app.use(compression())
app.use(express.json({ limit: BODY_LIMIT }))
app.use(express.text({ limit: BODY_LIMIT, type: 'text/*' }))
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      defaultSrc: [(process.env.CSP_DEFAULT || '\'self\'')],
      connectSrc: [(process.env.CSP_DEFAULT || '\'self\'')].concat(cspConnect),
      scriptSrc: [(process.env.CSP_DEFAULT || '\'self\'')],
      imgSrc: [(process.env.CSP_DEFAULT || '\'self\'')].concat(['data:']),
      styleSrc: [(process.env.CSP_DEFAULT || '\'self\'')].concat(['unsafe-inline'])
    }
  },
  crossOriginEmbedderPolicy: false
}))
app.use(cors({ origin: corsOrigin, credentials: false }))

// HTTP logger without PII
app.use(createLogger())

// Prometheus metrics middleware
if (METRICS_ENABLED) {
  app.use((req, res, next) => {
    const stop = metrics.httpStartTimer(req.route ? req.route.path : req.path)
    res.on('finish', () => {
      stop()
      metrics.httpCount(req.method, req.route ? req.route.path : req.path, res.statusCode)
    })
    next()
  })
}

const limiter = rateLimit({ windowMs: RATE_WINDOW, max: RATE_MAX, standardHeaders: true, legacyHeaders: false })
app.use(limiter)

// Health extends
const startedAt = Date.now()
app.get('/health', (_req, res) => res.json({ ok: true, ts: Date.now(), uptimeSec: Math.round((Date.now()-startedAt)/1000), version: pkg.version }))

// Auth
app.post('/auth/register-parent', registerParent)
app.post('/auth/login', login)
app.get('/me', requireAuth, me)

// Profiles and parental controls
app.post('/profiles/child', requireAuth, requireRole('parent'), createChild)
app.get('/profiles/child', requireAuth, requireRole('parent'), listChildren)
app.post('/contacts/whitelist', requireAuth, requireRole('parent'), addWhitelist)

// Moderation admin (parent)
app.get('/mod/whitelist', requireAuth, requireRole('parent'), getWL)
app.post('/mod/whitelist', requireAuth, requireRole('parent'), setWL)
app.get('/mod/stats', requireAuth, requireRole('parent'), modStats)

// Metrics endpoint
if (METRICS_ENABLED) {
  app.get(METRICS_PATH, async (req, res) => {
    if (METRICS_TOKEN && (req.headers['authorization']||'') !== ('Bearer ' + METRICS_TOKEN)) {
      return res.status(401).send('unauthorized')
    }
    res.set('Content-Type', metrics.register.contentType)
    res.end(await metrics.register.metrics())
  })
}

// Socket.IO
const server = http.createServer(app)
const io = require('socket.io')(server, { cors: { origin: corsOrigin, methods: ['GET','POST'] } })

io.use((socket, next) => {
  try {
    const token = (socket.handshake.auth && socket.handshake.auth.token) || null
    if (!token) return next()
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'dev')
    socket.user = payload
    return next()
  } catch (e) { return next() }
})

io.on('connection', (socket) => {
  metrics.socketsInc(1)
  socket.on('disconnect', () => metrics.socketsInc(-1))

  socket.data.lastMsg = 0
  socket.on('chat:message', (msg) => {
    const now = Date.now()
    if (now - (socket.data.lastMsg || 0) < MSG_MIN_INTERVAL) {
      metrics.socketMsg('block')
      socket.emit('system:block', { reason:'rate_limited' })
      return
    }
    socket.data.lastMsg = now

    const safe = sanitizeMessage(msg)
    if (!safe) { metrics.socketMsg('block'); socket.emit('system:block', { reason:'invalid' }); return }

    if (ENABLE_CONTROLS) {
      const verdict = enforceControls(socket.user, safe)
      if (!verdict.ok) { metrics.socketMsg('block'); socket.emit('system:block', { reason: verdict.reason }); return }
    }

    if (ENABLE_MOD) {
      const uid = (socket.user && socket.user.sub) || socket.id
      const state = getState(uid)
      const ev = evaluate(safe.text, MOD_CFG, state)
      if (!ev.ok) {
        const st = recordViolation(uid, MOD_CFG)
        metrics.socketMsg('block')
        socket.emit('system:block', { reason: ev.reason, mutedUntil: st.mutedUntil||0 })
        return
      }
    }

    metrics.socketMsg('ack')
    socket.emit('system:ack', { ok:true })
    if (safe.room) { socket.to(safe.room).emit('chat:message', safe); socket.join(safe.room) }
    else { socket.broadcast.emit('chat:message', safe) }
  })
})

function sanitizeMessage(input) {
  try {
    const obj = Object(input) === input ? input : {}
    const from = String(obj.from || '').slice(0, 50)
    const text = String(obj.text || '').replace(/\u0000/g, '').slice(0, MSG_MAX_LEN)
    const ts = Number(obj.ts || Date.now())
    const room = obj.room ? String(obj.room).slice(0, 100) : null
    if (!from || !text) return null
    return { from, text, ts, room }
  } catch (e) { return null }
}

// controls (from Stage 3), left inline
function enforceControls(user, msg) {
  if (!user) return { ok:false, reason:'auth_required' }
  const roles = (user.roles||[])
  if (roles.indexOf('child') === -1) return { ok:true }
  if (!msg.room) return { ok:false, reason:'room_required' }
  const db = readJson()
  const child = db.children.find(c=>c.id===user.sub)
  if (!child) return { ok:false, reason:'child_unknown' }
  const parent = db.users.find(u=>u.children && u.children.indexOf(child.id)!==-1)
  if (!parent) return { ok:false, reason:'parent_unknown' }
  const wl = parent.whitelist || []
  if (wl.indexOf(msg.room) === -1) return { ok:false, reason:'not_whitelisted' }
  const schedules = (((db.controls||{}).schedules||{})[child.id]) || []
  if (!isWithinSchedule(schedules, new Date())) return { ok:false, reason:'outside_schedule' }
  return { ok:true }
}
function isWithinSchedule(rules, now) {
  if (!Array.isArray(rules) || !rules.length) return false
  const dow = now.getDay()
  const hh = now.getHours(); const mm = now.getMinutes()
  const cur = hh*60+mm
  for (const r of rules) {
    const start = toMinutes(r.start); const end = toMinutes(r.end)
    if (r.days && r.days.indexOf(dow)!==-1) {
      if (start <= end) { if (cur>=start && cur<=end) return true }
      else { if (cur>=start || cur<=end) return true }
    }
  }
  return false
}
function toMinutes(hhmm){ try{ const p = String(hhmm).split(':'); return Number(p[0])*60+Number(p[1]) }catch(e){ return 0 } }

server.listen(PORT, () => { console.log('KUKUTalk backend listening on http://localhost:' + PORT) })
