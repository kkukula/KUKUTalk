import React from 'react'

function fmt(ts){ try { return new Date(ts).toLocaleTimeString() } catch(e){ return '' } }

export default function MessageList({ items, me, system }) {
  return (
    <div style={{border:'1px solid #ddd', borderRadius:8, padding:12, minHeight:220, marginBottom:10, background:'#fff'}}>
      {(items && items.length) ? items.map((m, i) => (
        <div key={i} style={{margin:'8px 0'}}>
          <strong style={{color: m.from===me ? '#0a7' : '#06c'}}>{m.from}</strong>
          <span style={{opacity:0.6, marginLeft:8, fontSize:12}}>{fmt(m.ts)}</span>
          <div>{m.text}</div>
          {m.room ? <div style={{fontSize:12, opacity:0.7}}>room: {m.room}</div> : null}
        </div>
      )) : <div style={{opacity:0.6}}>No messages yet</div>}
      {system && system.type==='block' ? (
        <div style={{marginTop:8, padding:8, background:'#fee', border:'1px solid #f99', borderRadius:6}}>
          Blocked by server: {String((system.payload && system.payload.reason) || 'unknown')}
        </div>
      ) : null}
    </div>
  )
}
