KUKUTalk monorepo

apps/web     - React + Vite client
apps/backend - Express + Socket.IO server
packages/shared - future shared utils
